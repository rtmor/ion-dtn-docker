#ifndef IONDTN_GDSLOGGER_H
#define IONDTN_GDSLOGGER_H

void	logToLogcat(char *text);

#endif //IONDTN_GDSLOGGER_H
