InterPlanetary Networking Special Interest Group (IPNSIG)

Pilot Projects Working Group

https://ipnsig.org


This repository consists of a collection of modified DTN implementations and custom tools used by the IPNSIG PWG for testing on the Solar System/Interplanetary Internet Prototype Network.


Join our developers channel on Discord:

https://discord.gg/w9Wz4t5EJK
